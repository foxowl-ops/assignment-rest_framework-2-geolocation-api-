from django.contrib import admin
from items.models import Item
# Register your models here.

admin.site.register(Item)